this hand model was publicly available:
downloadable from https://raw.githubusercontent.com/IntelPerceptual/UnityPXC/master/UnityPluginTest/default_hand.chr


