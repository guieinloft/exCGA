rm  -r obj/
rm  */*.pdb
rm  */*.ipdb
rm  */*.iobj
rm  */*.ilk
rm  */*.filters
rm  */*.user
rm   *.sdf


