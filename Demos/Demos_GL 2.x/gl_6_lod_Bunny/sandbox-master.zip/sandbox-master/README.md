sandbox
=======

sandbox for various 3d math, geometry, graphics and physics code
